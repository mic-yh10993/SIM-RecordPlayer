package com.sim.recordplayer.client;

import com.sim.recordplayer.SIMRecordPlayer;
import com.sim.recordplayer.audio.AudioPlayer;
import com.sim.recordplayer.block.RecordPlayerBlock;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import java.util.Map;

public class RecordPlayerClientManager {
    private static final Map<class_2338, String> playingBlocks = new ConcurrentHashMap<>();
    private static AudioPlayer currentAudio;
    private static class_2338 currentPos;
    private static final double MAX_DISTANCE = 32.0;
    private static final double FADE_START = 22.0;

    public static void tick(class_310 client) {
        if (client.field_1687 == null || client.field_1724 == null) {
            stopAll();
            return;
        }

        playingBlocks.clear();

        class_243 playerPos = client.field_1724.method_19538();
        int px = (int) playerPos.field_1352;
        int py = (int) playerPos.field_1351;
        int pz = (int) playerPos.field_1350;
        int range = (int) Math.ceil(MAX_DISTANCE) + 1;

        for (int x = px - range; x <= px + range; x++) {
            for (int y = py - range; y <= py + range; y++) {
                for (int z = pz - range; z <= pz + range; z++) {
                    class_2338 pos = new class_2338(x, y, z);
                    class_2680 state = client.field_1687.method_8320(pos);
                    if (state.method_26204() instanceof RecordPlayerBlock block) {
                        boolean isPlaying = state.method_11654(RecordPlayerBlock.PLAYING);
                        if (isPlaying) {
                            playingBlocks.put(pos.method_10062(), block.getSongName());
                        }
                    }
                }
            }
        }

        class_2338 foundPos = null;
        String foundSong = null;
        for (Map.Entry<class_2338, String> entry : playingBlocks.entrySet()) {
            foundPos = entry.getKey();
            foundSong = entry.getValue();
            break;
        }

        if (foundPos == null || foundSong == null) {
            if (currentAudio != null) {
                SIMRecordPlayer.LOGGER.info("No playing record player found, stopping audio");
            }
            stopAll();
            return;
        }

        if (currentPos != null && !currentPos.equals(foundPos)) {
            SIMRecordPlayer.LOGGER.info("Record player changed from {} to {}", currentPos, foundPos);
            stopAll();
        }

        double distance = client.field_1724.method_19538().method_1022(
                new class_243(foundPos.method_10263() + 0.5, foundPos.method_10264() + 0.5, foundPos.method_10260() + 0.5));

        if (distance > MAX_DISTANCE) {
            stopAll();
            return;
        }

        if (currentAudio == null || !currentAudio.isPlaying()) {
            String mp3File = getMp3ForSong(foundSong);
            if (mp3File == null) {
                SIMRecordPlayer.LOGGER.warn("Unknown song: {}", foundSong);
                return;
            }
            SIMRecordPlayer.LOGGER.info("Starting audio for song: {} at distance: {}", foundSong, distance);
            currentAudio = new AudioPlayer(mp3File);
            currentAudio.play();
            currentPos = foundPos;
        }

        float volume;
        if (distance <= FADE_START) {
            volume = 1.0f;
        } else {
            volume = (float) (1.0 - (distance - FADE_START) / (MAX_DISTANCE - FADE_START));
            volume = Math.max(0f, Math.min(1f, volume));
        }
        currentAudio.setVolume(volume);
    }

    private static String getMp3ForSong(String songName) {
        return switch (songName) {
            case "hoyo_mix_remembrance_of_the_heart" -> "HOYO-MiX - 心忆 Remembrance of the Heart.mp3";
            case "moon_halo" -> "Moon Halo.mp3";
            case "la_vaguelette" -> "轻涟 La vaguelette.mp3";
            default -> null;
        };
    }

    public static void stopAll() {
        if (currentAudio != null) {
            currentAudio.stop();
            currentAudio = null;
        }
        currentPos = null;
    }
}
