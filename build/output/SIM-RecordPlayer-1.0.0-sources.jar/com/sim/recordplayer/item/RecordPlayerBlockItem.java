package com.sim.recordplayer.item;

import com.sim.recordplayer.block.RecordPlayerBlock;
import net.minecraft.class_1747;
import net.minecraft.class_1750;
import net.minecraft.class_2248;
import net.minecraft.class_2680;

public class RecordPlayerBlockItem extends class_1747 {
    public RecordPlayerBlockItem(class_2248 block, class_1793 settings) {
        super(block, settings);
    }

    @Override
    public class_2680 method_7707(class_1750 context) {
        class_2680 state = super.method_7707(context);
        if (state != null) {
            return state.method_11657(RecordPlayerBlock.PLAYING, true);
        }
        return null;
    }
}
