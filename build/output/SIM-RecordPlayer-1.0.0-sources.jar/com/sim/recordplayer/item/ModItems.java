package com.sim.recordplayer.item;

import com.sim.recordplayer.SIMRecordPlayer;
import com.sim.recordplayer.block.ModBlocks;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public class ModItems {
    public static final class_1792 RECORD_PLAYER_HOYO_MIX_心忆_REMEMBRANCE_OF_THE_HEART = new RecordPlayerBlockItem(
            ModBlocks.RECORD_PLAYER_HOYO_MIX_心忆_REMEMBRANCE_OF_THE_HEART, new class_1792.class_1793());
    public static final class_1792 RECORD_PLAYER_MOON_HALO = new RecordPlayerBlockItem(
            ModBlocks.RECORD_PLAYER_MOON_HALO, new class_1792.class_1793());
    public static final class_1792 RECORD_PLAYER_轻涟_LA_VAGUELETTE = new RecordPlayerBlockItem(
            ModBlocks.RECORD_PLAYER_轻涟_LA_VAGUELETTE, new class_1792.class_1793());

    public static final class_5321<class_1761> SIM_RECORD_PLAYER_GROUP = class_5321.method_29179(class_7924.field_44688,
            class_2960.method_60655(SIMRecordPlayer.MOD_ID, "sim_record_player_group"));

    public static void registerItems() {
        class_2378.method_10230(class_7923.field_41178,
                class_2960.method_60655(SIMRecordPlayer.MOD_ID, "record_player_hoyo_mix_心忆_remembrance_of_the_heart"), RECORD_PLAYER_HOYO_MIX_心忆_REMEMBRANCE_OF_THE_HEART);
        class_2378.method_10230(class_7923.field_41178,
                class_2960.method_60655(SIMRecordPlayer.MOD_ID, "record_player_moon_halo"), RECORD_PLAYER_MOON_HALO);
        class_2378.method_10230(class_7923.field_41178,
                class_2960.method_60655(SIMRecordPlayer.MOD_ID, "record_player_轻涟_la_vaguelette"), RECORD_PLAYER_轻涟_LA_VAGUELETTE);

        class_2378.method_39197(class_7923.field_44687, SIM_RECORD_PLAYER_GROUP,
                FabricItemGroup.builder()
                        .method_47320(() -> new class_1799(RECORD_PLAYER_HOYO_MIX_心忆_REMEMBRANCE_OF_THE_HEART))
                        .method_47321(class_2561.method_43471("itemGroup.simrecordplayer.sim_record_player_group"))
                        .method_47317((enabledFeatures, entries) -> {
                            entries.method_45421(RECORD_PLAYER_HOYO_MIX_心忆_REMEMBRANCE_OF_THE_HEART);
                            entries.method_45421(RECORD_PLAYER_MOON_HALO);
                            entries.method_45421(RECORD_PLAYER_轻涟_LA_VAGUELETTE);
                        })
                        .method_47324());

        SIMRecordPlayer.LOGGER.info("Registered items");
    }
}
