package com.sim.recordplayer.block;

import com.sim.recordplayer.SIMRecordPlayer;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2746;
import net.minecraft.class_3965;

public class RecordPlayerBlock extends class_2248 implements class_2343 {
    public static final class_2746 PLAYING = class_2746.method_11825("playing");
    private final String songName;
    private final String displayName;

    public RecordPlayerBlock(String songName, String displayName, class_2251 settings) {
        super(settings);
        this.songName = songName;
        this.displayName = displayName;
        this.method_9590(this.field_10647.method_11664().method_11657(PLAYING, false));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(PLAYING);
    }

    public String getSongName() {
        return songName;
    }

    public String getDisplayName() {
        return displayName;
    }

    @Override
    protected class_1269 method_55766(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_3965 hit) {
        if (!world.field_9236) {
            boolean playing = !state.method_11654(PLAYING);
            world.method_8652(pos, state.method_11657(PLAYING, playing), 3);
        }
        return class_1269.method_29236(world.field_9236);
    }

    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new RecordPlayerBlockEntity(songName, pos, state);
    }
}
