package com.sim.recordplayer.block;

import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_7225;
import org.jetbrains.annotations.Nullable;

public class RecordPlayerBlockEntity extends class_2586 {
    private final String songName;

    public RecordPlayerBlockEntity(String songName, class_2338 pos, class_2680 state) {
        super(ModBlocks.RECORD_PLAYER_BLOCK_ENTITY, pos, state);
        this.songName = songName;
    }

    public String getSongName() {
        return songName;
    }

    public boolean isPlaying() {
        class_2680 state = method_11010();
        return state.method_28498(RecordPlayerBlock.PLAYING) && state.method_11654(RecordPlayerBlock.PLAYING);
    }

    public void setPlaying(boolean playing) {
        if (method_10997() != null && !method_10997().field_9236) {
            class_2338 pos = method_11016();
            class_2680 state = method_10997().method_8320(pos);
            if (state.method_26204() instanceof RecordPlayerBlock) {
                method_10997().method_8652(pos, state.method_11657(RecordPlayerBlock.PLAYING, playing), 3);
            }
        }
    }

    @Override
    protected void method_11007(class_2487 nbt, class_7225.class_7874 registries) {
        super.method_11007(nbt, registries);
        nbt.method_10582("SongName", songName);
    }

    @Override
    public void method_11014(class_2487 nbt, class_7225.class_7874 registries) {
        super.method_11014(nbt, registries);
    }

    @Nullable
    @Override
    public class_2596<class_2602> method_38235() {
        return class_2622.method_38585(this);
    }

    @Override
    public class_2487 method_16887(class_7225.class_7874 registries) {
        return method_38244(registries);
    }
}
