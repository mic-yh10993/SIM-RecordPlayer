package com.sim.recordplayer.block;

import com.sim.recordplayer.SIMRecordPlayer;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class ModBlocks {
    public static final class_2248 RECORD_PLAYER_HOYO_MIX_心忆_REMEMBRANCE_OF_THE_HEART = new RecordPlayerBlock("hoyo_mix_心忆_remembrance_of_the_heart", "HOYO-MiX - 心忆 Remembrance of the Heart",
            class_2248.Settings.method_9637().method_9632(2.0f).method_22488());
    public static final class_2248 RECORD_PLAYER_MOON_HALO = new RecordPlayerBlock("moon_halo", "Moon Halo",
            class_2248.Settings.method_9637().method_9632(2.0f).method_22488());
    public static final class_2248 RECORD_PLAYER_轻涟_LA_VAGUELETTE = new RecordPlayerBlock("轻涟_la_vaguelette", "轻涟 La vaguelette",
            class_2248.Settings.method_9637().method_9632(2.0f).method_22488());

    public static final class_2591<RecordPlayerBlockEntity> RECORD_PLAYER_BLOCK_ENTITY =
            class_2591.class_2592.method_20528(
                    (pos, state) -> new RecordPlayerBlockEntity("", pos, state),
                    RECORD_PLAYER_HOYO_MIX_心忆_REMEMBRANCE_OF_THE_HEART, RECORD_PLAYER_MOON_HALO, RECORD_PLAYER_轻涟_LA_VAGUELETTE
            ).method_11034(null);

    public static void registerBlocks() {
        class_2378.method_10230(class_7923.field_41175,
                class_2960.method_60655(SIMRecordPlayer.MOD_ID, "record_player_hoyo_mix_心忆_remembrance_of_the_heart"), RECORD_PLAYER_HOYO_MIX_心忆_REMEMBRANCE_OF_THE_HEART);
        class_2378.method_10230(class_7923.field_41175,
                class_2960.method_60655(SIMRecordPlayer.MOD_ID, "record_player_moon_halo"), RECORD_PLAYER_MOON_HALO);
        class_2378.method_10230(class_7923.field_41175,
                class_2960.method_60655(SIMRecordPlayer.MOD_ID, "record_player_轻涟_la_vaguelette"), RECORD_PLAYER_轻涟_LA_VAGUELETTE);

        class_2378.method_10230(class_7923.field_41181,
                class_2960.method_60655(SIMRecordPlayer.MOD_ID, "record_player"), RECORD_PLAYER_BLOCK_ENTITY);

        SIMRecordPlayer.LOGGER.info("Registered {} record player blocks", 3);
    }
}
