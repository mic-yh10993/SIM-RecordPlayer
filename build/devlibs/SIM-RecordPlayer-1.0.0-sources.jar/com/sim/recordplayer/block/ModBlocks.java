package com.sim.recordplayer.block;

import com.sim.recordplayer.SIMRecordPlayer;
import net.minecraft.block.Block;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class ModBlocks {
    public static final Block RECORD_PLAYER_HOYO_MIX_心忆_REMEMBRANCE_OF_THE_HEART = new RecordPlayerBlock("hoyo_mix_心忆_remembrance_of_the_heart", "HOYO-MiX - 心忆 Remembrance of the Heart",
            Block.Settings.create().strength(2.0f).nonOpaque());
    public static final Block RECORD_PLAYER_MOON_HALO = new RecordPlayerBlock("moon_halo", "Moon Halo",
            Block.Settings.create().strength(2.0f).nonOpaque());
    public static final Block RECORD_PLAYER_未来再见 = new RecordPlayerBlock("未来再见", "未来再见",
            Block.Settings.create().strength(2.0f).nonOpaque());
    public static final Block RECORD_PLAYER_轻涟_LA_VAGUELETTE = new RecordPlayerBlock("轻涟_la_vaguelette", "轻涟 La vaguelette",
            Block.Settings.create().strength(2.0f).nonOpaque());

    public static final BlockEntityType<RecordPlayerBlockEntity> RECORD_PLAYER_BLOCK_ENTITY =
            BlockEntityType.Builder.create(
                    (pos, state) -> new RecordPlayerBlockEntity("", pos, state),
                    RECORD_PLAYER_HOYO_MIX_心忆_REMEMBRANCE_OF_THE_HEART, RECORD_PLAYER_MOON_HALO, RECORD_PLAYER_未来再见, RECORD_PLAYER_轻涟_LA_VAGUELETTE
            ).build(null);

    public static void registerBlocks() {
        Registry.register(Registries.BLOCK,
                Identifier.of(SIMRecordPlayer.MOD_ID, "record_player_hoyo_mix_心忆_remembrance_of_the_heart"), RECORD_PLAYER_HOYO_MIX_心忆_REMEMBRANCE_OF_THE_HEART);
        Registry.register(Registries.BLOCK,
                Identifier.of(SIMRecordPlayer.MOD_ID, "record_player_moon_halo"), RECORD_PLAYER_MOON_HALO);
        Registry.register(Registries.BLOCK,
                Identifier.of(SIMRecordPlayer.MOD_ID, "record_player_未来再见"), RECORD_PLAYER_未来再见);
        Registry.register(Registries.BLOCK,
                Identifier.of(SIMRecordPlayer.MOD_ID, "record_player_轻涟_la_vaguelette"), RECORD_PLAYER_轻涟_LA_VAGUELETTE);

        Registry.register(Registries.BLOCK_ENTITY_TYPE,
                Identifier.of(SIMRecordPlayer.MOD_ID, "record_player"), RECORD_PLAYER_BLOCK_ENTITY);

        SIMRecordPlayer.LOGGER.info("Registered {} record player blocks", 4);
    }
}
