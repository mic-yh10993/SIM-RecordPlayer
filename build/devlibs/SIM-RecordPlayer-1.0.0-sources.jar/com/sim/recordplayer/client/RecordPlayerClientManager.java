package com.sim.recordplayer.client;

import com.sim.recordplayer.SIMRecordPlayer;
import com.sim.recordplayer.audio.AudioPlayer;
import com.sim.recordplayer.block.RecordPlayerBlock;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

import java.util.concurrent.ConcurrentHashMap;
import java.util.Map;

public class RecordPlayerClientManager {
    private static final Map<BlockPos, String> playingBlocks = new ConcurrentHashMap<>();
    private static AudioPlayer currentAudio;
    private static BlockPos currentPos;
    private static final double MAX_DISTANCE = 32.0;
    private static final double FADE_START = 22.0;

    public static void tick(MinecraftClient client) {
        if (client.world == null || client.player == null) {
            stopAll();
            return;
        }

        playingBlocks.clear();

        Vec3d playerPos = client.player.getPos();
        int px = (int) playerPos.x;
        int py = (int) playerPos.y;
        int pz = (int) playerPos.z;
        int range = (int) Math.ceil(MAX_DISTANCE) + 1;

        for (int x = px - range; x <= px + range; x++) {
            for (int y = py - range; y <= py + range; y++) {
                for (int z = pz - range; z <= pz + range; z++) {
                    BlockPos pos = new BlockPos(x, y, z);
                    BlockState state = client.world.getBlockState(pos);
                    if (state.getBlock() instanceof RecordPlayerBlock block) {
                        boolean isPlaying = state.get(RecordPlayerBlock.PLAYING);
                        if (isPlaying) {
                            playingBlocks.put(pos.toImmutable(), block.getSongName());
                        }
                    }
                }
            }
        }

        BlockPos foundPos = null;
        String foundSong = null;
        for (Map.Entry<BlockPos, String> entry : playingBlocks.entrySet()) {
            foundPos = entry.getKey();
            foundSong = entry.getValue();
            break;
        }

        if (foundPos == null || foundSong == null) {
            if (currentAudio != null) {
                SIMRecordPlayer.LOGGER.info("No playing record player found, stopping audio");
            }
            stopAll();
            return;
        }

        if (currentPos != null && !currentPos.equals(foundPos)) {
            SIMRecordPlayer.LOGGER.info("Record player changed from {} to {}", currentPos, foundPos);
            stopAll();
        }

        double distance = client.player.getPos().distanceTo(
                new Vec3d(foundPos.getX() + 0.5, foundPos.getY() + 0.5, foundPos.getZ() + 0.5));

        if (distance > MAX_DISTANCE) {
            stopAll();
            return;
        }

        if (currentAudio == null || !currentAudio.isPlaying()) {
            String mp3File = getMp3ForSong(foundSong);
            if (mp3File == null) {
                SIMRecordPlayer.LOGGER.warn("Unknown song: {}", foundSong);
                return;
            }
            SIMRecordPlayer.LOGGER.info("Starting audio for song: {} at distance: {}", foundSong, distance);
            currentAudio = new AudioPlayer(mp3File);
            currentAudio.play();
            currentPos = foundPos;
        }

        float volume;
        if (distance <= FADE_START) {
            volume = 1.0f;
        } else {
            volume = (float) (1.0 - (distance - FADE_START) / (MAX_DISTANCE - FADE_START));
            volume = Math.max(0f, Math.min(1f, volume));
        }
        currentAudio.setVolume(volume);
    }

    private static String getMp3ForSong(String songName) {
        return switch (songName) {
            case "hoyo_mix_心忆_remembrance_of_the_heart" -> "HOYO-MiX - 心忆 Remembrance of the Heart.mp3";
            case "moon_halo" -> "Moon Halo.mp3";
            case "未来再见" -> "未来再见.mp3";
            case "轻涟_la_vaguelette" -> "轻涟 La vaguelette.mp3";
            default -> null;
        };
    }

    public static void stopAll() {
        if (currentAudio != null) {
            currentAudio.stop();
            currentAudio = null;
        }
        currentPos = null;
    }
}
