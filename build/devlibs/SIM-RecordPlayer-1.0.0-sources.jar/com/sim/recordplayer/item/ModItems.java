package com.sim.recordplayer.item;

import com.sim.recordplayer.SIMRecordPlayer;
import com.sim.recordplayer.block.ModBlocks;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public class ModItems {
    public static final Item RECORD_PLAYER_HOYO_MIX_心忆_REMEMBRANCE_OF_THE_HEART = new RecordPlayerBlockItem(
            ModBlocks.RECORD_PLAYER_HOYO_MIX_心忆_REMEMBRANCE_OF_THE_HEART, new Item.Settings());
    public static final Item RECORD_PLAYER_MOON_HALO = new RecordPlayerBlockItem(
            ModBlocks.RECORD_PLAYER_MOON_HALO, new Item.Settings());
    public static final Item RECORD_PLAYER_未来再见 = new RecordPlayerBlockItem(
            ModBlocks.RECORD_PLAYER_未来再见, new Item.Settings());
    public static final Item RECORD_PLAYER_轻涟_LA_VAGUELETTE = new RecordPlayerBlockItem(
            ModBlocks.RECORD_PLAYER_轻涟_LA_VAGUELETTE, new Item.Settings());

    public static final RegistryKey<ItemGroup> SIM_RECORD_PLAYER_GROUP = RegistryKey.of(RegistryKeys.ITEM_GROUP,
            Identifier.of(SIMRecordPlayer.MOD_ID, "sim_record_player_group"));

    public static void registerItems() {
        Registry.register(Registries.ITEM,
                Identifier.of(SIMRecordPlayer.MOD_ID, "record_player_hoyo_mix_心忆_remembrance_of_the_heart"), RECORD_PLAYER_HOYO_MIX_心忆_REMEMBRANCE_OF_THE_HEART);
        Registry.register(Registries.ITEM,
                Identifier.of(SIMRecordPlayer.MOD_ID, "record_player_moon_halo"), RECORD_PLAYER_MOON_HALO);
        Registry.register(Registries.ITEM,
                Identifier.of(SIMRecordPlayer.MOD_ID, "record_player_未来再见"), RECORD_PLAYER_未来再见);
        Registry.register(Registries.ITEM,
                Identifier.of(SIMRecordPlayer.MOD_ID, "record_player_轻涟_la_vaguelette"), RECORD_PLAYER_轻涟_LA_VAGUELETTE);

        Registry.register(Registries.ITEM_GROUP, SIM_RECORD_PLAYER_GROUP,
                FabricItemGroup.builder()
                        .icon(() -> new ItemStack(RECORD_PLAYER_HOYO_MIX_心忆_REMEMBRANCE_OF_THE_HEART))
                        .displayName(Text.translatable("itemGroup.simrecordplayer.sim_record_player_group"))
                        .entries((enabledFeatures, entries) -> {
                            entries.add(RECORD_PLAYER_HOYO_MIX_心忆_REMEMBRANCE_OF_THE_HEART);
                            entries.add(RECORD_PLAYER_MOON_HALO);
                            entries.add(RECORD_PLAYER_未来再见);
                            entries.add(RECORD_PLAYER_轻涟_LA_VAGUELETTE);
                        })
                        .build());

        SIMRecordPlayer.LOGGER.info("Registered items");
    }
}
